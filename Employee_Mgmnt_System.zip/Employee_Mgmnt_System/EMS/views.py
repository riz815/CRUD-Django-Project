from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import Add_Employee
# Create your views here.

def index(request):
    
    data = Add_Employee.objects.all()
    
    return render(request,"index.html",{'data':data})

def add_employee(request):
    if request.method=="POST":
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        
        myemp = Add_Employee()
        myemp.firstname = fname
        myemp.lastname = lname
        myemp.email = email
        myemp.phone = phone
        myemp.save()
        # print("submitted")
        # return redirect("index.html/")
    return render(request,"add-employee.html",{})

def delete_employee(request, my_id):
    # print(my_id)
    emp_delte = Add_Employee.objects.get(id=my_id)
    emp_delte.delete()
    
    return redirect(index)

def update_form(request, up_id):
    emp_data = Add_Employee.objects.get(id=up_id) 
    
    return render(request, "update_form.html", {'data':emp_data})

def do_update_form(request, update_id):
    if request.method=='POST':
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        
        myemp = Add_Employee.objects.get(id=update_id)
        myemp.firstname = fname
        myemp.lastname = lname
        myemp.email = email
        myemp.phone = phone
        myemp.save()
     
    return redirect(index)
       