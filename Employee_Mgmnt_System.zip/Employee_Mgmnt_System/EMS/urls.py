from django.urls import path
from .import views
urlpatterns = [
    
    path("",views.index, name="index"),
    path("index/",views.index, name="index"),
    path("delete/<int:my_id>",views.delete_employee),
    path("update_form/<int:up_id>",views.update_form),
    path("do_update_form/<int:update_id>",views.do_update_form),
    
    path('add-employee/', views.add_employee, name='add_employee'),
]
